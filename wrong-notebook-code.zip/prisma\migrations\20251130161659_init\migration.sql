-- AlterTable
ALTER TABLE "ErrorItem" ADD COLUMN "paperLevel" TEXT;
