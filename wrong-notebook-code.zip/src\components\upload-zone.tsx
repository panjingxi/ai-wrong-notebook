"use client";

import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Card, CardContent } from "@/components/ui/card";
import { UploadCloud, Loader2 } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

interface UploadZoneProps {
    onImageSelect: (file: File) => void;  // 改为传递 File 对象
    isAnalyzing: boolean;
}

export function UploadZone({ onImageSelect, isAnalyzing }: UploadZoneProps) {
    const { t } = useLanguage();

    const onDrop = useCallback(
        (acceptedFiles: File[]) => {
            const file = acceptedFiles[0];
            if (file) {
                // 直接传递 File 对象，让父组件处理压缩
                onImageSelect(file);
            }
        },
        [onImageSelect]
    );

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            "image/*": [".jpeg", ".jpg", ".png"],
        },
        maxFiles: 1,
        disabled: isAnalyzing,
    });

    return (
        <div
            {...getRootProps()}
            className={`relative group border-2 border-dashed rounded-[2rem] cursor-pointer transition-all duration-500 overflow-hidden ${isDragActive
                    ? "border-primary bg-primary/10 scale-[0.99]"
                    : "border-primary/20 hover:border-primary/40 bg-card/20 backdrop-blur-sm"
                }`}
        >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

            <CardContent className="flex flex-col items-center justify-center py-16 space-y-6 text-center min-h-[350px] relative z-10">
                <input {...getInputProps()} />
                <div className={`p-6 rounded-3xl transition-all duration-500 ${isAnalyzing ? "bg-primary/20 scale-110 rotate-12" : "bg-primary/10 group-hover:bg-primary/20 group-hover:scale-110"
                    }`}>
                    {isAnalyzing ? (
                        <Loader2 className="h-12 w-12 text-primary animate-spin" />
                    ) : (
                        <UploadCloud className="h-12 w-12 text-primary group-hover:text-primary transition-colors" />
                    )}
                </div>
                <div className="space-y-2">
                    <h3 className="font-bold text-2xl tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text">
                        {isAnalyzing ? t.app.analyzing : t.upload.analyze}
                    </h3>
                    <p className="text-muted-foreground text-lg max-w-sm mx-auto leading-relaxed">
                        {isAnalyzing ? "Our AI is analyzing your question..." : t.app.dragDrop}
                    </p>
                    <div className="flex items-center justify-center gap-2 pt-4">
                        <span className="px-3 py-1 bg-primary/10 rounded-full text-xs font-semibold text-primary uppercase tracking-wider">
                            {t.upload.support || "JPG, PNG, JPEG"}
                        </span>
                    </div>
                </div>
            </CardContent>
        </div>
    );
}
